#include <stdio.h>
#include <stdlib.h>
#include "avl.h"



/* POUR DEBUGGER : fonction qui transforme des avl en fichiers .dot */

#include "string.h"

void avl_to_dot_walker(FILE* fd, avl a, avl parent){
	if (a) {
		if (a != parent) fprintf(fd, "%ld -> %ld\n", (size_t) parent, (size_t) a);
		fprintf(fd, "%ld [label=\"%d\"];\n", (size_t) a, a->valeur);
		fprintf(fd, "%ld [xlabel=\"%d\"];\n", (size_t) a, a->facteur_equilibrage);
		avl_to_dot_walker(fd, a->gauche, a);
		avl_to_dot_walker(fd, a->droite, a);
	}
}

void avl_vers_dot(const char* nom_fichier, avl a){
	int n = strlen(nom_fichier);
	char nom_fichier_complet[n + 5];
	strcpy(nom_fichier_complet,nom_fichier);
	strcat(nom_fichier_complet,".dot");
	FILE* fd = fopen(nom_fichier_complet, "w+");
	fputs("digraph G {\nrankdir=\"TB\";\n", fd);
	if (a){
		avl_to_dot_walker(fd, a, a);
	}
	fputs("}\n", fd);
	fclose(fd);
}
