#include "iterateurs.h"



/* !!!!! ITÉRATEURS POUR LES ENTIERS POSITIFS (0 JUSQU'À N-1) !!!!! **/	

iterateur entier_init(int n){
	iterateur it = malloc(sizeof(struct iterateur_s));
	
	it->valeur = 0;
	it->est_fini = n <= 0;
	
	return it;
}		

void entier_suivant(iterateur it, int n){
	(it->valeur)++;
	it->est_fini = (it->valeur == n);
}	

void entier_termine(iterateur it){
	free(it);
}	


/* !!!!! ITÉRATEURS POUR LES CHAÎNES DE CARACTÈRES !!!!! **/	

iterateur string_init(char* ch){
	iterateur it = malloc(sizeof(struct iterateur_s));
	
	it->valeur = ch[0];
	it->est_fini = (ch[0] == '\0');
	it->data.curseur_string = ch;
	
	return it;
}		

void string_suivant(iterateur it, char* ch){	
	char* ptr = it->data.curseur_string;
	
	ptr++;
	
	it->valeur = *ptr;
	it->est_fini = (*ptr == '\0');
	it->data.curseur_string = ptr;	
}	

void string_termine(iterateur it){
	free(it);
}	

//~ À vous de compléter pour les 5 structures de données restantes...

