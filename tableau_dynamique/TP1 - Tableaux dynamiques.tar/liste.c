#include "liste.h"
#include <stdlib.h>
#include <stdio.h>


size_t longueur(Liste l) {
	return l->taille;
}

// À vous de compléter le reste !
