#include "liste.h"
#include "benchmark.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>


int main(){

	/** À décommenter pour tester ! (Il faudra que vous rajoutiez des tests vous-même.) **/
	
	// Liste l = liste_vide();
	
	// assert(longueur(l) == 0);
	
	// ajouter_en_fin(l,4);
	// ajouter_en_fin(l,8);
	
	// assert(longueur(l) == 2);
	// assert(element(l,0) == 4);
	// assert(element(l,-1) == 8);


	return EXIT_SUCCESS;
}
